<ul class="sidebar-menu" data-widget="tree">
	<li class="header">MAIN NAVIGATION</li>
	<li class="active"><a href="index.html"><i class="fa fa-home"></i> Dashboard</a></li>
	<li class="treeview">
	  <a href="#">
		<i class="fa fa-laptop"></i>
		<span>Master Data</span>
		<span class="pull-right-container">
		  <i class="fa fa-angle-left pull-right"></i>
		</span>
	  </a>
	  <ul class="treeview-menu">
		<li><a href="kelas.html"><i class="fa fa-circle-o"></i> Kelas</a></li>
		<li><a href="mapel.html"><i class="fa fa-circle-o"></i> Matapelajaran</a></li>
		<li><a href="tentor.php"><i class="fa fa-circle-o"></i> Tentor</a></li>
	  </ul>
	</li>
	<li class="treeview">
	  <a href="#">
		<i class="fa fa-edit"></i> <span>Akun</span>
		<span class="pull-right-container">
		  <i class="fa fa-angle-left pull-right"></i>
		</span>
	  </a>
	  <ul class="treeview-menu">
		<li><a href="logout.html"><i class="fa fa-circle-o"></i> Admin</a></li>
	  </ul>
	</li>
</ul>